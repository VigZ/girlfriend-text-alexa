SKILL_NAME = "Text My Girlfriend"
HELP_MESSAGE = "You can say tell me to text your girlfriend or boyfriend, just give me their number when prompted, and I'll take care of the rest!"
HELP_REPROMPT = "What can I help you with?"
STOP_MESSAGE = "Goodbye!"
FALLBACK_MESSAGE = "I don't believe this skill can do that. Though, I can send cute things to your significant other. Shall I do that?"
FALLBACK_REPROMPT = 'What can I help you with?'
EXCEPTION_MESSAGE = "Sorry. I cannot help you with that."

data = [
  'I’m so tired. I spent the whole night looking up at the stars matching each one with a unique reason why I love you. I ran out of stars before I could finish.',
  'Life without the one I love is like a broken pencil – it is pointless.',
  'If you hold onto one of my hands, I will be able to conquer the world.',
  'I can’t give you the world – you deserve it – but I can promise to give you my world.',
  'If you let me, I would hold you forever.',
  'You want to know why I keep telling you how much I love you? I want to make sure that the last thought in your mind is filled with love and happiness.',
  'You must be a dictionary because you add meaning to my life.',
  'Our love is a mocha latte. You’re hot like coffee, sweet like sugar and filled with a little extra pep to make it simply perfect.',
  'I fall in love every day that I wake up next to you.',
  'I was going to buy you a flower, and then I realized that you’re far more beautiful than any rose I could pick.',
  'If life had a pause button, I would be stuck in time with you replaying and pausing every perfect moment we spend together.',
  'When people ask me “what’s the best thing that ever happened to you?” It’s always so easy to tell them how you have made my life complete.',
  'Looooooooooovvvveeeeee Youuuuuuuuuuuuuu',
]
